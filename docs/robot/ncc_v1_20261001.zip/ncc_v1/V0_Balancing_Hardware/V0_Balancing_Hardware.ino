// /*
//   BANLINHKIEN.COM
//   PRJ: XE ROBOT CÂN BẰNG 
//   🛠️ Hướng Dẫn Cân Chỉnh Robot Trước Khi Nạp Code
//     - Dựng thẳng robot một cách ổn định:
//     - Kê các động cơ sao cho robot đứng thẳng hoàn toàn theo phương thẳng đứng, không bị nghiêng.
//     - Có thể dùng giá đỡ hoặc kê cố định bằng vật cứng để đảm bảo trạng thái cân bằng khi không có chuyển động.
//   Nạp chương trình đọc giá trị cân bằng:
//     - Tải và nạp chương trình đo balance_value vào vi điều khiển.
//     - Giá trị này rất quan trọng – nó được dùng làm mốc thăng bằng chuẩn cho robot.
//     - Ghi lại giá trị balance_value hiển thị trên Serial Monitor:
//     - Dùng giá trị này để cấu hình trong chương trình chính V1, V2, giúp robot giữ thăng bằng chính xác.
//   🔗 Tham khảo chi tiết phương pháp cân bằng:
//     👉 Video hướng dẫn của Joop Brokking – https://www.youtube.com/watch?v=6WWqo-Yr8lA&t=1s.
// */

/*
  BANLINHKIEN.COM
  PRJ: XE ROBOT CÂN BẰNG 
  ✅ Phiên bản sửa cho MPU6050 clone
  - Bỏ kiểm tra WHO_AM_I cố định (chấp nhận mọi giá trị phản hồi)
  - Thêm bước “wake up” trước khi đọc dữ liệu
  - Tự động nhận MPU6050 tại địa chỉ 0x68 hoặc 0x69
*/

#include <Wire.h>

byte error, MPU_6050_found = 0, nunchuck_found = 0;
byte lowByte, highByte;
int address, nDevices;

void setup() {
  Wire.begin();
  TWBR = 12; // tốc độ I2C ~400kHz
  Serial.begin(9600);
  Serial.println(F("Scanning I2C bus..."));
}

void loop() {
  Serial.println(F("Scanning I2C bus..."));
  nDevices = 0;

  for (address = 1; address < 127; address++) {
    Wire.beginTransmission(address);
    error = Wire.endTransmission();

    if (error == 0) {
      Serial.print(F("I2C device found at address 0x"));
      if (address < 16) Serial.print("0");
      Serial.println(address, HEX);
      nDevices++;

      // === MPU6050 check ===
      if (address == 0x68 || address == 0x69) {
        Serial.println(F("This could be a MPU-6050 (or compatible clone)"));

        // Wake up the MPU (đánh thức chip)
        Wire.beginTransmission(address);
        Wire.write(0x6B);
        Wire.write(0x00); // clear sleep bit
        Wire.endTransmission();
        delay(10);

        // Đọc thanh ghi WHO_AM_I để tham khảo
        Wire.beginTransmission(address);
        Wire.write(0x75);
        Wire.endTransmission();
        Wire.requestFrom(address, 1);
        while (Wire.available() < 1);
        lowByte = Wire.read();

        Serial.print(F("WHO_AM_I response: 0x"));
        Serial.println(lowByte, HEX);

        // Chấp nhận mọi phản hồi (0x68, 0x72, 0x70...)
        MPU_6050_found = 1;
        Serial.println(F("MPU6050 (clone or real) accepted. Starting Gyro..."));
        set_gyro_registers(address);
      }

      // === Nunchuck check ===
      if (address == 0x52) {
        Serial.println(F("This could be a Nunchuck"));
        Serial.println(F("Trying to initialise the device..."));
        Wire.beginTransmission(0x52);
        Wire.write(0xF0); Wire.write(0x55);
        Wire.endTransmission();
        delay(20);
        Wire.beginTransmission(0x52);
        Wire.write(0xFB); Wire.write(0x00);
        Wire.endTransmission();
        delay(20);

        Wire.beginTransmission(0x52);
        Wire.write(0x00);
        Wire.endTransmission();
        Wire.requestFrom(0x52, 1);
        while (Wire.available() < 1);
        lowByte = Wire.read();
        if (lowByte > 100 && lowByte < 160) {
          Serial.print(F("Data response normal: "));
          Serial.println(lowByte);
          nunchuck_found = 1;
        } else {
          Serial.print(F("Data response abnormal: "));
          Serial.println(lowByte);
        }
      }
    } else if (error == 4) {
      Serial.print(F("Unknown error at address 0x"));
      if (address < 16) Serial.print("0");
      Serial.println(address, HEX);
    }
  }

  if (nDevices == 0)
    Serial.println(F("No I2C devices found\n"));
  else
    Serial.println(F("done\n"));

  // === Đọc dữ liệu từ MPU ===
  if (MPU_6050_found) {
    Serial.println(F("Reading balance value..."));
    Wire.beginTransmission(0x68);
    Wire.write(0x3F);
    Wire.endTransmission();
    Wire.requestFrom(0x68, 2);
    int balance_value = (Wire.read() << 8 | Wire.read()) * -1;
    Serial.print(F("Balance value: "));
    Serial.println(balance_value);
    delay(20);

    Serial.println(F("Printing raw gyro values..."));
    for (int i = 0; i < 20; i++) {
      Wire.beginTransmission(0x68);
      Wire.write(0x43);
      Wire.endTransmission();
      Wire.requestFrom(0x68, 6);
      while (Wire.available() < 6);
      int gx = Wire.read() << 8 | Wire.read();
      int gy = Wire.read() << 8 | Wire.read();
      int gz = Wire.read() << 8 | Wire.read();
      Serial.print("Gyro X = "); Serial.print(gx);
      Serial.print("  Gyro Y = "); Serial.print(gy);
      Serial.print("  Gyro Z = "); Serial.println(gz);
      delay(100);
    }
    Serial.println();
  } else {
    Serial.println(F("No MPU6050 or clone found at address 0x68/0x69"));
  }

  // === Nunchuck data ===
  if (nunchuck_found) {
    Serial.println(F("Printing raw Nunchuck values..."));
    for (int i = 0; i < 20; i++) {
      Wire.beginTransmission(0x52);
      Wire.write(0x00);
      Wire.endTransmission();
      Wire.requestFrom(0x52, 2);
      while (Wire.available() < 2);
      int joyX = Wire.read();
      int joyY = Wire.read();
      Serial.print("Joystick X = "); Serial.print(joyX);
      Serial.print("  Y = "); Serial.println(joyY);
      delay(100);
    }
  } else {
    Serial.println(F("No Nunchuck device found at address 0x52"));
  }

  while (1);
}

void set_gyro_registers(int addr) {
  // Setup MPU6050 registers
  Wire.beginTransmission(addr);
  Wire.write(0x6B);
  Wire.write(0x00); // wake up
  Wire.endTransmission();

  Wire.beginTransmission(addr);
  Wire.write(0x1B);
  Wire.write(0x00); // ±250°/s
  Wire.endTransmission();

  Wire.beginTransmission(addr);
  Wire.write(0x1C);
  Wire.write(0x08); // ±4g
  Wire.endTransmission();

  Wire.beginTransmission(addr);
  Wire.write(0x1A);
  Wire.write(0x03); // DLPF ~43Hz
  Wire.endTransmission();
}







