# Prompt dán vào Claude Code (repo EIDE, đã có docs/review-v3/)

Gói bổ sung nằm ở `docs/review-v3-supplement/`. Hãy:
1. Đọc `docs/review-v3-supplement/README_BO_SUNG.md`, rồi đọc **toàn bộ** `docs/md/EIDE-MEM-42_Quan_ly_Bo_nho_va_Nen_Bo_nho.md` (thay mục B6 của MDD-40) `docs/md/EIDE-ING-43_Duong_ong_Nap_Tai_lieu_va_Trich_xuat.md` (chi tiết hoá C3, sửa bỏ sót Office/docx), và `docs/md/EIDE-SCH-44_Sinh_So_do_KiCad_va_Render.md` (tính năng mới, cách ly bằng cờ; **máy không cài KiCad**).
2. Rà mã hiện tại (bộ nhớ/ngữ cảnh: rpc/loop, transcript, EIDE.md, ledger; nạp tài liệu: ingest.classify, archive.list, fact.extract, rag) so với hai tài liệu. Viết `docs/md/EIDE-GAP-44_Ra_soat_MEM_ING.md`: mỗi yêu cầu MEM-01…MEM-24, ING-01…ING-20 và SCH-01…SCH-22 → CÓ / MỘT PHẦN / KHÔNG / KHÁC, tệp:dòng, ca đo (MEM01–14, ING01–16, SCH01–18, TC liên quan), hành động, bước (MEM-A…D, ING-A…E, SCH-A…D). Xác minh bằng cách đọc mã.
3. Dừng, tóm tắt gap report (10 sai lệch quan trọng nhất, ước lượng công), nêu 3 điểm chờ chốt ở README §3. Chờ tôi gật.
4. Khi tôi gật: làm MEM-A → ING-A → MEM-B → ING-B → MEM-C → ING-C → ING-D → SCH-A → SCH-B → MEM-D → ING-E → SCH-C → SCH-D (SCH chỉ bắt đầu khi ING-D xong; mỗi bước SCH phải kèm báo cáo hồi quy hai chế độ cờ giống 100 %) (đan xen để mỗi bước có ca đo xanh). Mỗi bước một nhánh; unit test phần xác định; chạy ca MEM/ING tương ứng ×5 và hồi quy 16 ca đang đạt. Thay `ui/` bằng bản trong gói; kiểm Excel ánh xạ ra "ĐẠT". Sai lệch → `[DEV-2xx]` trong EIDE-DEV-LOG.md.
5. Kết thúc mỗi bước: báo cáo ca đạt/không, DEV-2xx mới, đề xuất bước tiếp.
Ngôn ngữ: mã tiếng Anh; thông điệp người dùng, explain, tài liệu tiếng Việt.
